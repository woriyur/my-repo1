// setup angular
var app = angular.module('myTODO',['ionic']);